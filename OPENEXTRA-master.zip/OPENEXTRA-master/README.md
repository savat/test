# Script Installation
# OpenVPN, Pritunl, Proxy, SHH Dropbear, Web Panel

- wget https://raw.githubusercontent.com/nwqionm/OPENEXTRA/master/Install
- chmod +x Install
- bash Install

# หลังจากอัพโหลดสคริปท์ลงเซิฟเวอร์เสร็จเรียบร้อย
# ครั้งถัดไปเพียงพิมว่า bash Install เพื่อเข้าสู่เมนูการติดตั้ง
